create
    definer = root@localhost procedure GetProjectCost(IN proj_id bigint, OUT cost decimal(15, 2))
BEGIN
    DECLARE total_salary_sum DECIMAL(15, 2) DEFAULT 0;
    DECLARE current_prog_id BIGINT;
    DECLARE current_prog_salary DECIMAL(15, 2);
    DECLARE done INT DEFAULT FALSE;
    
    DECLARE prog_cursor CURSOR FOR SELECT id FROM programmers WHERE project_id = proj_id;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN prog_cursor;

    read_loop: LOOP
        FETCH prog_cursor INTO current_prog_id;
        IF done THEN
            LEAVE read_loop;
        END IF;
        
        CALL GetProgrammerSalary(current_prog_id, current_prog_salary);
        IF current_prog_salary IS NOT NULL THEN
            SET total_salary_sum = total_salary_sum + current_prog_salary;
        END IF;
    END LOOP;

    CLOSE prog_cursor;

    SET cost = total_salary_sum * 2;
END;

