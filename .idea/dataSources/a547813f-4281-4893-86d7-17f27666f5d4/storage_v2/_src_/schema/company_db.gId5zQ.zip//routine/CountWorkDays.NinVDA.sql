create
    definer = root@localhost function CountWorkDays(start_d date, end_d date) returns int deterministic
BEGIN
    DECLARE work_days INT DEFAULT 0;
    DECLARE current_d DATE;
    
    IF start_d IS NULL OR end_d IS NULL OR start_d > end_d THEN
        RETURN 0;
    END IF;

    SET current_d = start_d;
    WHILE current_d <= end_d DO
        -- DAYOFWEEK: 1=Sun, 2=Mon, ..., 7=Sat
        IF DAYOFWEEK(current_d) NOT IN (1, 7) THEN
            SET work_days = work_days + 1;
        END IF;
        SET current_d = DATE_ADD(current_d, INTERVAL 1 DAY);
    END WHILE;
    RETURN work_days;
END;

