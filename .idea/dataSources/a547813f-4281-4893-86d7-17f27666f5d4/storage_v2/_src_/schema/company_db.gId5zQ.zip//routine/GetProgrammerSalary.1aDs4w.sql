create
    definer = root@localhost procedure GetProgrammerSalary(IN prog_id bigint, OUT salary decimal(15, 2))
BEGIN
    DECLARE v_start_date, v_end_date, v_effective_end_date DATE;
    DECLARE v_hourly_rate DECIMAL(10, 2);
    DECLARE v_full_time BOOLEAN;
    DECLARE v_work_days INT;
    DECLARE v_hours_per_day DECIMAL(4,1);
    
    SELECT start_date, end_date, hourly_rate, full_time
    INTO v_start_date, v_end_date, v_hourly_rate, v_full_time
    FROM programmers WHERE id = prog_id;

    SET v_effective_end_date = IFNULL(v_end_date, CURDATE());
    SET v_work_days = CountWorkDays(v_start_date, v_effective_end_date);
    SET v_hours_per_day = IF(v_full_time, 8.0, 4.0);
    
    SET salary = v_work_days * v_hours_per_day * v_hourly_rate * 1.77;
END;

